// Dalam scanForEmail() function, selepas berjaya detect email:
updateStats() {
    chrome.storage.local.get(['scannedCount', 'blockedCount'], (result) => {
        const scanned = (result.scannedCount || 0) + 1;
        chrome.storage.local.set({ scannedCount: scanned });
        
        // Send to popup jika terbuka
        chrome.runtime.sendMessage({
            action: "updateStats",
            scannedCount: scanned,
            blockedCount: result.blockedCount || 0
        });
    });
}

// Panggil updateStats() bila email berjaya di-scan